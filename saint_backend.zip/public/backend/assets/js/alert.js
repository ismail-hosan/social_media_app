$(document).ready(function() {
    setTimeout(function() {
        $('#successAlert').fadeOut('slow');
    }, 2000);

    setTimeout(function() {
        $('#errorAlert').fadeOut('slow');
    }, 2000);
});
