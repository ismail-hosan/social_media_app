// Exports the "save" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/save')
//   ES2015:
//     import 'tinymce/plugins/save'
require('./plugin.js');