<div class="w-full flex min-h-full h-full rounded-lg" >
    <div class=" hidden md:grid bg-inherit border-r dark:border-gray-700   dark:bg-inherit  relative w-full h-full md:w-[360px] lg:w-[400px] xl:w-[500px]  shrink-0 overflow-y-auto  ">
       <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('wirechat.chats', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3270927936-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?> 
    </div>
    
    <main  class="  grid  w-full  grow  h-full min-h-min relative overflow-y-auto"  style="contain:content">
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('wirechat.chat', ['conversation' => ''.e($this->conversation->id).'']);

$__html = app('livewire')->mount($__name, $__params, 'lw-3270927936-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </main>

</div><?php /**PATH C:\laragon\www\saint_backend\resources\views/vendor/wirechat/livewire/pages/chat.blade.php ENDPATH**/ ?>