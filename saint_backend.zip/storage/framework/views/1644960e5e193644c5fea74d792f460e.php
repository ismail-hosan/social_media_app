<?php if (isset($component)) { $__componentOriginal500de2b4782698a6e0c3c3e2db574db5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal500de2b4782698a6e0c3c3e2db574db5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal500de2b4782698a6e0c3c3e2db574db5)): ?>
<?php $attributes = $__attributesOriginal500de2b4782698a6e0c3c3e2db574db5; ?>
<?php unset($__attributesOriginal500de2b4782698a6e0c3c3e2db574db5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal500de2b4782698a6e0c3c3e2db574db5)): ?>
<?php $component = $__componentOriginal500de2b4782698a6e0c3c3e2db574db5; ?>
<?php unset($__componentOriginal500de2b4782698a6e0c3c3e2db574db5); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\saint_backend\storage\framework\views/ac7070e4a9fa8b99ecf68b9b39382fd5.blade.php ENDPATH**/ ?>