<div 
<?php echo e($attributes->merge([ 'class'=>"w-full h-2 shadow-xs bg-gray-200 dark:bg-gray-700 "])); ?> >

</div><?php /**PATH C:\laragon\www\saint_backend\resources\views/vendor/wirechat/components/divider.blade.php ENDPATH**/ ?>