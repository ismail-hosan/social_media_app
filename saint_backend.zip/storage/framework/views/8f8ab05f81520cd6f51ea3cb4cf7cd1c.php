<div class="w-full flex min-h-full h-full rounded-lg" >
    <div class=" hidden md:grid bg-inherit border-r border-[var(--wc-light-border)] dark:border-[var(--wc-dark-border)]   dark:bg-inherit  relative w-full h-full md:w-[360px] lg:w-[400px] xl:w-[500px]  shrink-0 overflow-y-auto  ">
       <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('wirechat.chats', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2653833295-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?> 
    </div>
    
    <main  class="  grid  w-full  grow  h-full min-h-min relative overflow-y-auto"  style="contain:content">
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('wirechat.chat', ['conversation' => ''.e($this->conversation->id).'']);

$__html = app('livewire')->mount($__name, $__params, 'lw-2653833295-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </main>

</div><?php /**PATH C:\laragon\www\saint_backend\vendor\namu\wirechat\src/../resources/views/livewire/pages/chat.blade.php ENDPATH**/ ?>