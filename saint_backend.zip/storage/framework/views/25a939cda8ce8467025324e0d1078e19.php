<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'conversation' => null, //Should be conversation  ID (Int)
    'widget' => false
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'conversation' => null, //Should be conversation  ID (Int)
    'widget' => false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<?php if (isset($component)) { $__componentOriginala8e967b09b5c4c64e54a6b34db697d50 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8e967b09b5c4c64e54a6b34db697d50 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.actions.open-chat-drawer','data' => ['component' => 'wirechat.chat.info','dusk' => 'show_chat_info','conversation' => ''.e($conversation).'','widget' => $widget]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::actions.open-chat-drawer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['component' => 'wirechat.chat.info','dusk' => 'show_chat_info','conversation' => ''.e($conversation).'','widget' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($widget)]); ?>
<?php echo e($slot); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8e967b09b5c4c64e54a6b34db697d50)): ?>
<?php $attributes = $__attributesOriginala8e967b09b5c4c64e54a6b34db697d50; ?>
<?php unset($__attributesOriginala8e967b09b5c4c64e54a6b34db697d50); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8e967b09b5c4c64e54a6b34db697d50)): ?>
<?php $component = $__componentOriginala8e967b09b5c4c64e54a6b34db697d50; ?>
<?php unset($__componentOriginala8e967b09b5c4c64e54a6b34db697d50); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\saint_backend\vendor\namu\wirechat\src/../resources/views/components/actions/show-chat-info.blade.php ENDPATH**/ ?>