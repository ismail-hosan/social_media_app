<?php
       $authIsAdminInGroup=  $participant?->isAdmin();
       $authIsOwner=  $participant?->isOwner();
       $isGroup=  $conversation?->isGroup();

    ?>


<div x-ref="members"
    class="h-[calc(100vh_-_6rem)]  sm:h-[450px] bg-[var(--wc-light-primary)] dark:bg-[var(--wc-dark-primary)] dark:text-white border dark:border-gray-700 overflow-y-auto overflow-x-hidden  ">

    <header class=" sticky top-0 bg-[var(--wc-light-primary)] dark:bg-[var(--wc-dark-primary)] z-10 p-2">
        <div class="flex items-center justify-center pb-2">

            <?php if (isset($component)) { $__componentOriginal26ea44c72c653b6752926f8680c1095f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26ea44c72c653b6752926f8680c1095f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.actions.close-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::actions.close-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <button  dusk="close_modal_button"
                class="p-2 ml-0 text-gray-600 hover:bg-[var(--wc-light-secondary)] dark:hover:bg-[var(--wc-dark-secondary)] dark:hover:text-white rounded-full hover:text-gray-800 ">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class=" w-5 w-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
                </svg>

            </button>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26ea44c72c653b6752926f8680c1095f)): ?>
<?php $attributes = $__attributesOriginal26ea44c72c653b6752926f8680c1095f; ?>
<?php unset($__attributesOriginal26ea44c72c653b6752926f8680c1095f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26ea44c72c653b6752926f8680c1095f)): ?>
<?php $component = $__componentOriginal26ea44c72c653b6752926f8680c1095f; ?>
<?php unset($__componentOriginal26ea44c72c653b6752926f8680c1095f); ?>
<?php endif; ?>

            <h3 class=" mx-auto font-semibold "><?php echo e(__('wirechat::chat.group.members.heading.label')); ?> </h3>



        </div>

        
        <section class="flex flex-wrap items-center px-0 border-b dark:border-[var(--wc-dark-secondary)]">
            <input type="search" id="users-search-field" wire:model.live.debounce='search' autocomplete="off"
                placeholder="<?php echo e(__('wirechat::chat.group.members.inputs.search.placeholder')); ?>"
                class=" w-full border-0 w-auto dark:bg-[var(--wc-dark-primary)] outline-hidden focus:outline-hidden bg-[var(--wc-dark-parimary)] rounded-lg focus:ring-0 hover:ring-0">
        </section>

    </header>


    <div class="relative w-full p-2 ">
        
        <section class="my-4 grid">
            <!--[if BLOCK]><![endif]--><?php if(count($participants)!=0): ?>

                <ul class="overflow-auto flex flex-col">

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $loopParticipantIsAuth =
                                $participant->participantable_id == auth()->id() &&
                                $participant->participantable_type == auth()->user()->getMorphClass();
                        ?>
                        <li x-data="{ open: false }" x-ref="button" @click="open = ! open" x-init="$watch('open', value => {
                            $refs.members.style.overflow = value ? 'hidden' : '';
                        })"
                            aria-modal="true"
                            tabindex="0"
                            x-on:keydown.escape.stop="open=false"
                            @click.away ="open=false;" wire:key="users-<?php echo e($key); ?>"
                            :class="!open || 'bg-[var(--wc-light-secondary)] dark:bg-[var(--wc-dark-secondary)]'"
                            class="flex cursor-pointer group gap-2 items-center overflow-x-hidden p-2 py-3">

                            <label class="flex cursor-pointer gap-2 items-center w-full">
                                <?php if (isset($component)) { $__componentOriginal573e53ccc82ae542bef1ba188da3d396 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal573e53ccc82ae542bef1ba188da3d396 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.avatar','data' => ['src' => ''.e($participant->participantable->cover_url).'','class' => 'w-10 h-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => ''.e($participant->participantable->cover_url).'','class' => 'w-10 h-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal573e53ccc82ae542bef1ba188da3d396)): ?>
<?php $attributes = $__attributesOriginal573e53ccc82ae542bef1ba188da3d396; ?>
<?php unset($__attributesOriginal573e53ccc82ae542bef1ba188da3d396); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal573e53ccc82ae542bef1ba188da3d396)): ?>
<?php $component = $__componentOriginal573e53ccc82ae542bef1ba188da3d396; ?>
<?php unset($__componentOriginal573e53ccc82ae542bef1ba188da3d396); ?>
<?php endif; ?>

                                <div class="grid grid-cols-12 w-full ">
                                    <h6 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['transition-all truncate group-hover:underline col-span-10' ]); ?>">
                                        <?php echo e($loopParticipantIsAuth ? 'You' : $participant->participantable->display_name); ?></h6>
                                        <!--[if BLOCK]><![endif]--><?php if($participant->isOwner()|| $participant->isAdmin()): ?>
                                        <span  style="background-color: var(--wirechat-primary-color);" class=" flex items-center col-span-2 text-white text-xs font-medium ml-auto px-2.5 py-px rounded-sm ">
                                            <?php echo e($participant->isOwner()? __('wirechat::chat.group.members.labels.owner'): __('wirechat::chat.group.members.labels.admin')); ?>

                                        </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                </div>

                                <div x-show="open" x-anchor.bottom-end="$refs.button"
                                    class="ml-auto bg-[var(--wc-light-secondary)] dark:bg-[var(--wc-dark-secondary)] border-[var(--wc-light-primary) dark:border-[var(--wc-dark-primary)] py-4 shadow-sm border rounded-md grid space-y-2 w-52">
                                    

                                    <?php if (isset($component)) { $__componentOriginal560906e28a130682ce3b060aed8ccc4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal560906e28a130682ce3b060aed8ccc4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.dropdown-button','data' => ['wire:click' => 'sendMessage(\''.e($participant->id).'\')','class' => 'truncate ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::dropdown-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'sendMessage(\''.e($participant->id).'\')','class' => 'truncate ']); ?>
                                        <!--[if BLOCK]><![endif]--><?php if($loopParticipantIsAuth): ?>
                                            
                                        <?php echo e(__('wirechat::chat.group.members.actions.send_message_to_yourself.label')); ?>

                                        <?php else: ?>
                                        
                                        <?php echo e(__('wirechat::chat.group.members.actions.send_message_to_member.label',['member'=>$participant->participantable?->display_name ])); ?>

                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $attributes = $__attributesOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $component = $__componentOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__componentOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>

                                    <!--[if BLOCK]><![endif]--><?php if($authIsAdminInGroup || $authIsOwner): ?>
                                        
                                        
                                        <!--[if BLOCK]><![endif]--><?php if($authIsOwner && !$loopParticipantIsAuth): ?>
                                            <!--[if BLOCK]><![endif]--><?php if($participant->isAdmin()): ?>
                                                <?php if (isset($component)) { $__componentOriginal560906e28a130682ce3b060aed8ccc4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal560906e28a130682ce3b060aed8ccc4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.dropdown-button','data' => ['wire:click' => 'dismissAdmin(\''.e($participant->id).'\')','wire:confirm' => ''.e(__('wirechat::chat.group.members.actions.dismiss_admin.confirmation_message',['member'=>$participant->participantable?->display_name])).'','class' => '  ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::dropdown-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'dismissAdmin(\''.e($participant->id).'\')','wire:confirm' => ''.e(__('wirechat::chat.group.members.actions.dismiss_admin.confirmation_message',['member'=>$participant->participantable?->display_name])).'','class' => '  ']); ?>
                                                    <?php echo e(__('wirechat::chat.group.members.actions.dismiss_admin.label')); ?>

                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $attributes = $__attributesOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $component = $__componentOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__componentOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
                                            <?php else: ?>
                                                <?php if (isset($component)) { $__componentOriginal560906e28a130682ce3b060aed8ccc4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal560906e28a130682ce3b060aed8ccc4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.dropdown-button','data' => ['wire:click' => 'makeAdmin(\''.e($participant->id).'\')','wire:confirm' => ''.e(__('wirechat::chat.group.members.actions.make_admin.confirmation_message',['member'=>$participant->participantable?->display_name])).'','class' => ' ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::dropdown-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'makeAdmin(\''.e($participant->id).'\')','wire:confirm' => ''.e(__('wirechat::chat.group.members.actions.make_admin.confirmation_message',['member'=>$participant->participantable?->display_name])).'','class' => ' ']); ?>
                                                    <?php echo e(__('wirechat::chat.group.members.actions.make_admin.label')); ?>

                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $attributes = $__attributesOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $component = $__componentOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__componentOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                            
                                            <!--[if BLOCK]><![endif]--><?php if(!$participant->isOwner() && !$loopParticipantIsAuth && !$participant->isAdmin()): ?>
                                            <?php if (isset($component)) { $__componentOriginal560906e28a130682ce3b060aed8ccc4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal560906e28a130682ce3b060aed8ccc4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.dropdown-button','data' => ['wire:click' => 'removeFromGroup(\''.e($participant->id).'\')','wire:confirm' => ''.e(__('wirechat::chat.group.members.actions.remove_from_group.confirmation_message',['member'=>$participant->participantable?->display_name])).'','class' => 'text-red-500 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::dropdown-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'removeFromGroup(\''.e($participant->id).'\')','wire:confirm' => ''.e(__('wirechat::chat.group.members.actions.remove_from_group.confirmation_message',['member'=>$participant->participantable?->display_name])).'','class' => 'text-red-500 ']); ?>
                                                <?php echo e(__('wirechat::chat.group.members.actions.remove_from_group.label')); ?>

                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $attributes = $__attributesOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__attributesOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal560906e28a130682ce3b060aed8ccc4a)): ?>
<?php $component = $__componentOriginal560906e28a130682ce3b060aed8ccc4a; ?>
<?php unset($__componentOriginal560906e28a130682ce3b060aed8ccc4a); ?>
<?php endif; ?>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <?php else: ?>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



                                </div>
                            </label>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->



                </ul>


                
                <!--[if BLOCK]><![endif]--><?php if($canLoadMore): ?>
                    <section class="w-full justify-center flex my-3">
                        <button dusk="loadMoreButton" @click="$wire.loadMore()"
                            class=" text-sm dark:text-white hover:text-gray-700 transition-colors dark:hover:text-gray-500 dark:gray-200">
                            <?php echo e(__('wirechat::chat.group.members.actions.load_more.label')); ?>

                        </button>
                    </section>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <?php else: ?>

            <span class="m-auto"><?php echo e(__('wirechat::chat.group.members.labels.no_members_found')); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </section>
    </div>

</div>
<?php /**PATH C:\laragon\www\saint_backend\resources\views/vendor/wirechat/livewire/chat/group/members.blade.php ENDPATH**/ ?>