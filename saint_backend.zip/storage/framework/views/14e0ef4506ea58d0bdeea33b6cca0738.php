<!-- BEGIN: Vendor JS-->
<script src="<?php echo e(asset('backend/app-assets/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo e(asset('backend/app-assets/vendors/js/forms/validation/jquery.validate.min.js')); ?>"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="<?php echo e(asset('backend/app-assets/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(asset('backend/app-assets/js/core/app.js')); ?>"></script>
<!-- END: Theme JS-->


<script src="<?php echo e(asset('vendor/toaster/toastr.min.js')); ?>"></script>

<!-- BEGIN: Page JS-->
<script src="<?php echo e(asset('backend/app-assets/js/scripts/pages/page-auth-login.js')); ?>"></script>
<!-- END: Page JS-->

<script>
    $(document).ready(function() {
        toastr.options = {
            'closeButton': true,
            'debug': true,
            'newestOnTop': true,
            'progressBar': false,
            'positionClass': 'toast-top-center',
            'preventDuplicates': true,
            'showDuration': '1000',
            'hideDuration': '1000',
            'timeOut': '5000',
            'extendedTimeOut': '1000',
            'showEasing': 'linear',
            'hideEasing': 'linear',
            'showMethod': 'slideDown',
            'hideMethod': 'slideUp',
            'hover': false,
        };

        <?php if(Session::has('t-success')): ?>
            toastr.success("<?php echo e(session('t-success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('status')): ?>
            toastr.success("<?php echo e(session('status')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-error')): ?>
            toastr.error("<?php echo e(session('t-error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-info')): ?>
            toastr.info("<?php echo e(session('t-info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-warning')): ?>
            toastr.warning("<?php echo e(session('t-warning')); ?>");
        <?php endif; ?>
    });

    $(window).on('load', function() {
        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }
    })
</script>
<?php echo $__env->yieldPushContent('script'); ?>
<?php /**PATH C:\laragon\www\saint_backend\resources\views/auth/partials/script.blade.php ENDPATH**/ ?>