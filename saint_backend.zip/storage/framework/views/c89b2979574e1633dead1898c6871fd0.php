<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0">
        <span class="float-md-left d-block d-md-inline-block mt-25">
            COPYRIGHT &copy; <?php echo e(date('Y')); ?>

            <a class="ml-25" href="" target="_blank">
                <?php echo e(config('app.name')); ?>

            </a>
            <span class="d-none d-sm-inline-block">, All rights Reserved</span>
        </span>
        <span class="float-md-right d-none d-md-block">
        </span>
    </p>
</footer>
<?php /**PATH C:\laragon\www\saint_backend\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>