<?php $__env->startSection('title', 'FAQ Page'); ?>

<?php $__env->startPush('style'); ?>
    <link href="//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" rel="stylesheet" />
    <style>
        .dropify-wrapper {
            width: 160px;
        }

        #data-table th,
        #data-table td {
            text-align: center !important;
            vertical-align: middle !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content content">
        <div class="row">
            <div class="col-lg-5">
                <div class="card">
                    <div class="card-header">
                        <h4 class="m-0">FAQ <span id="faqtitle">Create</span></h4>
                    </div>
                    <div class="card-body">
                        <form id="createfaq" action="<?php echo e(route('faq.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label for="inputEmail3" class="col-3 col-form-label">Question ?</label>
                                        <div class="col-9">
                                            <textarea name="que" class="form-control" id="" placeholder="question..?" cols="5" rows="2"><?php echo e(old('que')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label for="inputEmail3" class="col-3 col-form-label">Answer</label>
                                        <div class="col-9">
                                            <textarea name="ans" class="ck-editor form-control <?php $__errorArgs = ['ans'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('ans')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="text-end">
                                        <button type="submit" class="btn btn-sm btn-primary">Create</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <form style="display: none;" id="editfaq" action="<?php echo e(route('faq.update')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label for="inputEmail3" class="col-3 col-form-label">Question ?</label>
                                        <div class="col-9">
                                            <textarea name="que" class="form-control" id="" placeholder="question..?" cols="5" rows="2"><?php echo e(old('que')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label for="inputEmail3" class="col-3 col-form-label">Answer</label>
                                        <div class="col-9">
                                            <textarea id="ans" name="ans" class="ck-editor form-control <?php $__errorArgs = ['ans'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('ans')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="text-end">
                                        <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="card">
                    <div class="card-header">
                        <h4 class="m-0">FAQ List</h4>
                    </div>
                    <div class="card-body">
                        <div class="accordion" id="accordionExample">
                            <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" style="display: flex;">
                                        <button style="flex: 25; border-radius: 0;"
                                            class="accordion-button <?php echo e($key == 0 ? '' : 'collapsed'); ?>" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($item->id); ?>"
                                            aria-expanded="<?php echo e($key == 0 ? 'true' : 'false'); ?>"
                                            aria-controls="collapse<?php echo e($item->id); ?>">
                                            <span><?php echo e($key+1 . "."); ?></span><?php echo e($item->que); ?>

                                        </button>
                                        <button style="flex: 1; border-radius:0;padding: .8rem 1.25rem;"
                                            onclick="editfaq(<?php echo e($item->id); ?>)" type="button" class="btn btn-info"><i
                                                class="mdi mdi-pencil"></i>
                                        </button>
                                        <button style="flex: 1; border-radius:0;padding: .8rem 1.25rem;" type="button"
                                            name="<?php echo e(route('faq.destroy',$item->id)); ?>" class="btn btn-danger del"><i class="mdi mdi-delete"></i>
                                        </button>
                                        <button style="flex: 3; border-radius:0;padding: .8rem 1.25rem;" type="button"
                                            onclick="statusfaq(<?php echo e($item->id); ?>)"
                                            class="btn btn-<?php echo e($item->status == 'active' ? 'success' : 'secondary'); ?>">
                                            <?php echo e($item->status == 'active' ? 'Active' : 'Inactive'); ?>

                                        </button>
                                    </h2>

                                    <div id="collapse<?php echo e($item->id); ?>"
                                        class="accordion-collapse collapse <?php echo e($key == 0 ? 'show' : ''); ?>"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <?php echo $item->ans; ?>

                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="alert alert-info">
                                    No Data Found
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="//code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>

    <script>
        let editors = [];

        document.querySelectorAll('.ck-editor').forEach(editorElement => {
            ClassicEditor
                .create(editorElement, {
                    removePlugins: ['CKFinderUploadAdapter', 'CKFinder', 'EasyImage', 'Image', 'ImageCaption',
                        'ImageStyle', 'ImageToolbar', 'ImageUpload', 'MediaEmbed'
                    ],
                    height: '500px'
                })
                .then(editor => {
                    editors.push(editor); // Store the editor instance for later use
                })
                .catch(error => {
                    console.error(error);
                });
        });
    </script>


    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                }
            });
        });
    </script>

    <script>
        function editfaq(id) {
            $.ajax({
                url: "<?php echo e(route('faq.get')); ?>",
                type: "GET",
                data: {
                    id: id
                },
                success: function(response) {
                    if (response) {
                        $('#faqtitle').text('Update');
                        $('#editfaq').show();
                        $('#createfaq').hide();
                        $('#editfaq input[name="id"]').val(response[0].id);
                        $('#editfaq textarea[name="que"]').val(response[0].que);

                        const editor = editors[1];
                        if (editor) {
                            editor.setData(response[0].ans); // Set content in CKEditor
                        }

                        $('html, body').animate({
                            scrollTop: 0
                        }, 'slow');
                    }
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    </script>
    <script>
        function statusfaq(id) {
            $.ajax({
                url: "<?php echo e(route('faq.status')); ?>",
                type: "GET",
                data: {
                    id: id
                },
                success: function(response) {
                    if (response.success) {
                        Toast.fire({
                            icon: 'success',
                            title: response.message
                        });

                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        Toast.fire({
                            icon: 'error',
                            title: 'Something Went Wrong'
                        });
                    }
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\saint_backend\resources\views/backend/layout/faq/index.blade.php ENDPATH**/ ?>