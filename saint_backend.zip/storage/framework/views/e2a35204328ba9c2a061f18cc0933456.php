<div class="flex gap-x-2 items-center">

    
    <!--[if BLOCK]><![endif]--><?php if($belongsToAuth): ?>
        <span class="font-bold text-xs dark:text-white/90 dark:font-normal">
            <?php echo app('translator')->get('wirechat::chats.labels.you'); ?>:
        </span>
    <?php elseif(!$belongsToAuth && $group !== null): ?>
        <span class="font-bold text-xs dark:text-white/80 dark:font-normal">
            <?php echo e($lastMessage->sendable?->display_name); ?>:
        </span>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'truncate text-sm dark:text-white  gap-2 items-center',
        'font-semibold text-black' =>
            !$isReadByAuth && !$lastMessage?->ownedBy($this->auth),
        'font-normal text-gray-600' =>
            $isReadByAuth && !$lastMessage?->ownedBy($this->auth),
        'font-normal text-gray-600' =>
            $isReadByAuth && $lastMessage?->ownedBy($this->auth),
    ]); ?>">
        <?php echo e($lastMessage->body != '' ? $lastMessage->body : ($lastMessage->isAttachment() ? '📎 '.__('wirechat::chats.labels.attachment') : '')); ?>

    </p>

    <span class="font-medium px-1 text-xs shrink-0 text-gray-800 dark:text-gray-50">
        <!--[if BLOCK]><![endif]--><?php if($lastMessage->created_at->diffInMinutes(now()) < 1): ?>
          <?php echo app('translator')->get('wirechat::chats.labels.now'); ?>
        <?php else: ?>
            <?php echo e($lastMessage->created_at->shortAbsoluteDiffForHumans()); ?>

        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </span>


</div>
<?php /**PATH C:\laragon\www\saint_backend\resources\views/vendor/wirechat/livewire/chats/partials/message-body.blade.php ENDPATH**/ ?>