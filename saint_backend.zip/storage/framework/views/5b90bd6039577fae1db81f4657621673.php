<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" />
    <style>
        .dropify-wrapper{
            height: inherit !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title', 'Admin Setting'); ?>
<?php $__env->startSection('content'); ?>

    <div class="app-content content ">
        <!-- General setting Form section start -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Admin Panel Setting</h3>
            </div>
            <div class="card-body">
                <form class="form" method="POST" action="<?php echo e(route('admin.settingupdate')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="country">Logo</label>
                                <input class="form-control dropify" type="file" name="admin_logo"
                                    <?php if(isset($setting->admin_logo)): ?>
                                                   data-default-file="<?php echo e(asset($setting->admin_logo)); ?>"
                                    <?php endif; ?>>
                                <?php $__errorArgs = ['admin_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="form-group">
                                <label for="country">Favicon</label>
                                <input class="form-control dropify" type="file" name="admin_favicon"
                                    <?php if(isset($setting->admin_favicon)): ?>
                                                data-default-file="<?php echo e(asset($setting->admin_favicon)); ?>"
                                    <?php endif; ?>>
                                <?php $__errorArgs = ['admin_favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-lg-10">
                            <div class="row">
                                <div class="col-lg-6 col-6">
                                    <div class="form-group">
                                        <label for="first-name-column">Title</label>
                                        <input type="text" id="admin_title" class="form-control"
                                            value="<?php echo e($setting->admin_title ?? ''); ?>" placeholder="Admin Title"
                                            name="admin_title" />
                                        <?php $__errorArgs = ['admin_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-5">
                                    <div class="form-group">
                                        <label for="first-name-column">Short Title</label>
                                        <input type="text" id="admin_short_title" class="form-control"
                                            value="<?php echo e($setting->admin_short_title ?? ''); ?>" placeholder="Admin Short Title"
                                            name="admin_short_title" />
                                        <?php $__errorArgs = ['admin_short_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-12">
                                    <div class="form-group">
                                        <label for="country">Copyright text</label>
                                        <input type="text" class="form-control" name="admin_copyright_text"
                                            id="admin_copyright_text" value="<?php echo e($setting->admin_copyright_text ?? ''); ?>"
                                            placeholder="Copyright Text">
                                        <?php $__errorArgs = ['admin_copyright_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-12 mt-3 text-end">
                                    <button type="submit" class="btn btn-primary mr-1">Update</button>
                                </div>
                            </div>

                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>

    <script>
        $('.dropify').dropify();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\saint_backend\resources\views/backend/layout/setting/admin-setting.blade.php ENDPATH**/ ?>