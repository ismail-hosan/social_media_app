
<div  onclick="Livewire.dispatch('closeWireChatModal')">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\saint_backend\resources\views/vendor/wirechat/components/actions/close-modal.blade.php ENDPATH**/ ?>